import serial
import time
import pyautogui
import keyboard  # For volume control

pyautogui.FAILSAFE = False

# Establish serial connection with Arduino
arduino_port = 'COM4'  # Update with the appropriate port
baud_rate = 9600
ser = serial.Serial(arduino_port, baud_rate)
time.sleep(2)  # Allow time for serial connection to establish

# Constants
SENSITIVITY_X = 100
SENSITIVITY_Y = 100
DEAD_ZONE = 10  # Ignore changes within this range
VOLUME_STEP = 10  # Smaller steps for fine volume control

# Smoothing variables
ALPHA = 0.7  # Smoothing factor (higher = smoother movement)
prev_move_x = 0
prev_move_y = 0

while True:
    # Read data from serial port
    line = ser.readline().decode('latin1').strip()

    try:
        # Extract values from the serial input
        ay, az, left_click, right_click, scroll_up, scroll_down, mapPotValue = map(int, line.split(','))

        # Adjust volume based on mapped potentiometer value
        if abs(mapPotValue - prev_mapPotValue) > 50:  # Threshold for dead zone
            if mapPotValue > prev_mapPotValue:
                for _ in range((mapPotValue - prev_mapPotValue) // VOLUME_STEP):
                    keyboard.press_and_release('volume_up')
            elif mapPotValue < prev_mapPotValue:
                for _ in range((prev_mapPotValue - mapPotValue) // VOLUME_STEP):
                    keyboard.press_and_release('volume_down')

            prev_mapPotValue = mapPotValue  # Update the previous value

        # Calculate movement
        raw_move_x = ay // SENSITIVITY_X
        raw_move_y = az // SENSITIVITY_Y

        # Apply smoothing
        smooth_move_x = int(ALPHA * raw_move_x + (1 - ALPHA) * prev_move_x)
        smooth_move_y = int(ALPHA * raw_move_y + (1 - ALPHA) * prev_move_y)

        prev_move_x = smooth_move_x
        prev_move_y = smooth_move_y

        # Check if the movement is outside the dead zone
        if abs(smooth_move_x) > DEAD_ZONE or abs(smooth_move_y) > DEAD_ZONE:
            pyautogui.moveRel(smooth_move_x, smooth_move_y)

        # Perform left click if the third input is 0
        if left_click == 0:
            pyautogui.click(button='left')

        # Perform right click if the fourth input is 0
        if right_click == 0:
            pyautogui.click(button='right')

    except ValueError:
        # Handle any conversion errors from malformed data
        continue

# Close serial connection
ser.close()